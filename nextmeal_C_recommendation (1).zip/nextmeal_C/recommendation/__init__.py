"""다음한끼 C: 설명 가능한 규칙 기반 메뉴 추천."""
from .engine import recommend
