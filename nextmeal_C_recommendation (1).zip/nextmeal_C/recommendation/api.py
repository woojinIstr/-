"""B 브랜치 FastAPI에 추가할 추천 API (v0.3 workspace 기반)."""
from datetime import date
from uuid import UUID
from fastapi import APIRouter, Depends, HTTPException, Query
from .engine import recommend


def register_recommendation_routes(app, identity):
    router = APIRouter(tags=['C · 메뉴 추천'])

    @router.get('/v3/recommendations')
    def suggestions(target_date: date | None = None,
                    servings: float = Query(1, gt=0, le=12),
                    max_minutes: int | None = Query(None, ge=1, le=1440),
                    excluded_ids: list[UUID] = Query(default=[]),
                    preferred_ids: list[UUID] = Query(default=[]),
                    limit: int = Query(10, ge=1, le=30),
                    auth=Depends(identity)):
        repository = app.state.workspace_repository
        revision, state = repository.load(*auth)
        result = recommend(state, target_date=str(target_date) if target_date else None,
                           servings=servings, max_minutes=max_minutes,
                           excluded_ids=[str(i) for i in excluded_ids],
                           preferred_ids=[str(i) for i in preferred_ids], limit=limit)
        return {'revision': revision, 'recommendations': result,
                'notice': '규칙 기반 추천입니다. 재고·식사 계획은 변경되지 않습니다.'}

    app.include_router(router)
