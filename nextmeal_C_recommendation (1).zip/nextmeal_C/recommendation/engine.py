"""B의 v0.3 workspace 스키마를 이용한 읽기 전용 추천 엔진.

추천 점수는 데모용 휴리스틱이며 실제 AI 모델이나 식품 안전 판정이 아니다.
"""
from datetime import date
from decimal import Decimal, InvalidOperation


def _num(value):
    try:
        result = Decimal(str(value))
        return result if result.is_finite() and result >= 0 else Decimal(0)
    except (InvalidOperation, ValueError, TypeError):
        return Decimal(0)


def recommend(workspace, *, target_date=None, servings=1, max_minutes=None,
              excluded_ids=None, preferred_ids=None, limit=10):
    """workspace: GET /v3/workspace 응답의 workspace 객체.

    반환 결과는 UI에 바로 표시할 수 있다. 서버 저장/재고 차감은 하지 않는다.
    """
    target_date = target_date or date.today().isoformat()
    date.fromisoformat(target_date)
    servings = _num(servings)
    if servings <= 0 or servings > 12:
        raise ValueError('인분은 0보다 크고 12 이하여야 합니다.')
    if max_minutes is not None and (not isinstance(max_minutes, int) or max_minutes < 1):
        raise ValueError('시간 제한은 1분 이상의 정수여야 합니다.')
    excluded = set(excluded_ids or [])
    preferred = set(preferred_ids or [])
    names = {x['id']: x['name'] for x in workspace.get('ingredients', [])}
    units = {x['id']: x['unit'] for x in workspace.get('ingredients', [])}
    available = {}
    expiry_dates = {}
    for lot in workspace.get('inventory', []):
        if lot.get('archived') or lot.get('quantity', 0) <= 0:
            continue
        if lot.get('purchased_on') and lot['purchased_on'] > target_date:
            continue
        if lot.get('expires_on') and lot['expires_on'] < target_date:
            continue
        ingredient_id = lot.get('ingredient_id')
        if lot.get('unit') != units.get(ingredient_id):
            continue
        available[ingredient_id] = available.get(ingredient_id, Decimal(0)) + _num(lot['quantity'])
        if lot.get('expires_on'):
            expiry_dates.setdefault(ingredient_id, []).append(lot['expires_on'])

    results = []
    for recipe in workspace.get('recipes', []):
        if recipe.get('archived') or not recipe.get('ingredients'):
            continue
        if max_minutes is not None and recipe.get('minutes', 999999) > max_minutes:
            continue
        parts = recipe['ingredients']
        if any(p.get('ingredient_id') in excluded for p in parts):
            continue
        base = _num(recipe.get('base_servings', 1))
        if base <= 0:
            continue
        missing = []
        fulfilled = 0
        urgency = 0
        preferred_count = 0
        for p in parts:
            key = p.get('ingredient_id')
            if key not in names or p.get('unit') != units.get(key):
                missing.append({'ingredient_id': key, 'name': names.get(key, '미등록 재료'),
                                'required': float(_num(p.get('quantity')) * servings / base),
                                'available': 0, 'shortage': None, 'unit': p.get('unit'), 'reason': '기준 단위 확인 필요'})
                continue
            needed = _num(p.get('quantity')) * servings / base
            have = available.get(key, Decimal(0))
            if needed <= have:
                fulfilled += 1
                if key in preferred: preferred_count += 1
                if expiry_dates.get(key):
                    days = (date.fromisoformat(min(expiry_dates[key])) - date.fromisoformat(target_date)).days
                    if 0 <= days <= 3: urgency += 1
            else:
                missing.append({'ingredient_id': key, 'name': names[key],
                                'required': float(needed), 'available': float(have),
                                'shortage': float(needed - have), 'unit': units[key]})
        coverage = fulfilled / len(parts)
        # 우선 재료·가까운 소비기한은 보조 점수. 부족 재료 수가 첫 우선순위.
        score = round(100 * coverage + 8 * preferred_count + 3 * urgency, 1)
        results.append({'recipe_id': recipe['id'], 'name': recipe['name'],
                        'minutes': recipe.get('minutes'), 'servings': float(servings),
                        'score': score, 'available_ingredient_count': fulfilled,
                        'total_ingredient_count': len(parts), 'missing': missing,
                        'ready': len(missing) == 0,
                        'reason': ('보유 재료만으로 조리 가능' if not missing else f'부족 재료 {len(missing)}종')
                                  + (f' · 우선 재료 {preferred_count}종 포함' if preferred_count else '')
                                  + (f' · 소비기한 임박 재료 {urgency}종 활용' if urgency else '')})
    results.sort(key=lambda x: (len(x['missing']), -x['score'], x['minutes'] if x['minutes'] is not None else 999999, x['name']))
    return results[:max(1, min(int(limit), 30))]
