import unittest
from recommendation.engine import recommend

MILK = '10000000-0000-4000-8000-000000000005'
RICE = '10000000-0000-4000-8000-000000000004'

class RecommendationTests(unittest.TestCase):
    def setUp(self):
        self.state = {
            'ingredients': [{'id': MILK, 'name': '우유', 'unit': 'ml'},
                            {'id': RICE, 'name': '밥', 'unit': 'g'}],
            'inventory': [{'id':'lot1', 'ingredient_id':MILK, 'quantity':250, 'unit':'ml',
                           'expires_on':'2026-11-19', 'purchased_on':'2026-11-10','archived':False},
                          {'id':'lot2','ingredient_id':RICE,'quantity':200,'unit':'g','archived':False}],
            'recipes':[{'id':'recipe1','name':'우유 리소토','base_servings':1,'minutes':15,
                        'archived':False,'ingredients':[{'ingredient_id':MILK,'quantity':200,'unit':'ml'},
                                                        {'ingredient_id':RICE,'quantity':150,'unit':'g'}]},
                       {'id':'recipe2','name':'밥','base_servings':1,'minutes':10,
                        'archived':False,'ingredients':[{'ingredient_id':RICE,'quantity':150,'unit':'g'}]}]}

    def test_ready_recipe(self):
        items = recommend(self.state,target_date='2026-11-16')
        self.assertTrue(items[0]['ready'])
        self.assertEqual(len(items),2)

    def test_missing_with_more_servings(self):
        items = recommend(self.state,target_date='2026-11-16',servings=2)
        risotto = next(x for x in items if x['recipe_id']=='recipe1')
        self.assertFalse(risotto['ready'])
        self.assertEqual({x['name'] for x in risotto['missing']}, {'우유','밥'})

    def test_exclude_and_time(self):
        items = recommend(self.state,target_date='2026-11-16',excluded_ids=[MILK],max_minutes=12)
        self.assertEqual([x['recipe_id'] for x in items], ['recipe2'])

    def test_expired_is_unavailable(self):
        items = recommend(self.state,target_date='2026-11-20')
        risotto = next(x for x in items if x['recipe_id']=='recipe1')
        self.assertIn('우유', [x['name'] for x in risotto['missing']])

    def test_does_not_mutate_workspace(self):
        from copy import deepcopy
        original = deepcopy(self.state)
        recommend(self.state,target_date='2026-11-16')
        self.assertEqual(self.state,original)

if __name__ == '__main__':
    unittest.main()
